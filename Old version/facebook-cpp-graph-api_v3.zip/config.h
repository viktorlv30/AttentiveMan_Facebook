#pragma once

//##################### Look here to configure !!!!! #####################

// you can use this to rapid prototype by auto-filling the login fields :)
QString FBApi::EMAIL   = "viktor.lv.30@gmail.com";
QString FBApi::PASSWORD= "gscnjyVFR369";

//here you put your API KEY you got from facebook
//
QString FBApi::API_KEY = "";
/*
here you put your APPLICATION ID you got from facebook
*/
QString FBApi::APPLICATION_ID = "";
QString FBApi::GENERAL_API_URL ="https://graph.facebook.com";
/*
here is the group id you wish you use for the api example in this demo
*/

// this isn't really used anymore but whatever
QString FBApi::GROUP_PING_ID = "";
